using System.ComponentModel.DataAnnotations;

namespace lost___found.Models
{
    public class LostFoundItem
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string ItemName { get; set; } = "";

        [Required]
        [StringLength(100)]
        public string Category { get; set; } = "";

        [Required]
        [StringLength(1000)]
        public string Description { get; set; } = "";

        [Required]
        [StringLength(200)]
        public string Location { get; set; } = "";

        [Required]
        public DateTime LostDate { get; set; }

        [Required]
        [EmailAddress]
        public string ContactEmail { get; set; } = "";

        public string UserId { get; set; } = "";

        public string Status { get; set; } = "Lost";

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}