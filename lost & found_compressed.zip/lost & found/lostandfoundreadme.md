# FindIt – Lost and Found Management System

## 1. Project Overview
FindIt is an ASP.NET Core MVC web application designed to help users report and manage lost items. The application uses ASP.NET Core Identity for user registration and login, Entity Framework Core for database operations, and Microsoft SQL Server for data storage.

## 2. Main Features
- User registration and login.
- User authentication using ASP.NET Core Identity.
- Report a lost item (for signed-in users).
- Store lost-item details in SQL Server.
- View saved lost-item records (where implemented in the application).

> Only describe or demonstrate features that are implemented and working in your submitted version.

## 3. Technologies Used
- ASP.NET Core MVC
- C#
- Razor Views
- Entity Framework Core
- ASP.NET Core Identity
- Microsoft SQL Server / SQL Server Express
- Visual Studio 2022 or .NET CLI

## 4. Project Structure
The project contains the following important folders and files (your actual project may contain additional files):

```text
lost & found/
├── Controllers/
├── Models/
├── Views/
├── Data/
├── Migrations/
├── wwwroot/
├── Program.cs
├── appsettings.json
└── lost___found.csproj
```

## 5. Database
Database name: `FindItDB`

The application uses Entity Framework Core migrations to create and update the database schema. The migrations folder should be included in the submitted project.

### Configure the connection string
Open `appsettings.json` and configure the `DefaultConnection` value for your own SQL Server instance. Example for SQL Server Express:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=.\\SQLEXPRESS;Database=FindItDB;Trusted_Connection=True;TrustServerCertificate=True;"
  }
}
```

If your `Program.cs` uses a different connection-string key, keep the key used by your application. Do not upload passwords, private credentials, or production connection strings to a public repository.

## 6. Requirements
- .NET SDK compatible with the target framework in `lost___found.csproj` (the project was configured for `net10.0`).
- SQL Server Express or another supported SQL Server instance.
- Entity Framework Core tools.

Check installed .NET SDKs:

```bash
dotnet --list-sdks
```

## 7. How to Run the Project

1. Install the required .NET SDK and SQL Server.
2. Open the project folder in Visual Studio or a terminal.
3. Check and update the database connection string in `appsettings.json`.
4. Open a terminal in the folder containing `lost___found.csproj`.
5. Restore dependencies:

```bash
dotnet restore
```

6. Build the project:

```bash
dotnet build
```

7. Apply the Entity Framework Core migrations:

```bash
dotnet ef database update
```

If the `dotnet ef` command is not available, install the EF Core command-line tool version compatible with the project's EF Core packages:

```bash
dotnet tool install --global dotnet-ef --version 10.0.0
```

If it is already installed, update it only if required:

```bash
dotnet tool update --global dotnet-ef --version 10.0.0
```

8. Run the application:

```bash
dotnet run
```

9. Open the local URL shown in the terminal (for example, `https://localhost:<port>`).

## 8. MVC Architecture
- **Model:** Represents application data and database entities, such as the user and lost-item models.
- **View:** Razor `.cshtml` pages that display the user interface.
- **Controller:** Handles incoming requests, application logic, and communication between models and views.

## 9. Security Notes
- Do not commit database passwords, API keys, or other secrets.
- Use the connection string appropriate for the computer where the project is being run.
- Keep authentication and authorization attributes and anti-forgery validation enabled where used by the application.

## 10. Author
BCA – ASP.NET Core MVC Project  
Project: FindIt – Lost and Found Management System
