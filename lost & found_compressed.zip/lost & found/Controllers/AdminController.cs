
using Microsoft.AspNetCore.Mvc;

namespace LostAndFound.Controllers
{
    public class AdminController : Controller
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
    }
}