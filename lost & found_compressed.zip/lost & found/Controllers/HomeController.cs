using System.Diagnostics;
using System.Security.Claims;
using lost___found.Models;
using lost___found.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace lost___found.Controllers
{
    public class HomeController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ApplicationDbContext _context;

        public HomeController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            ApplicationDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
        }

        // HOME
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        // REPORT LOST - GET
        [Authorize]
        [HttpGet]
        public IActionResult ReportLost()
        {
            return View();
        }

        // REPORT LOST - POST
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ReportLost(LostFoundItem model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            model.UserId = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "";
            model.Status = "Lost";
            model.CreatedAt = DateTime.Now;

            _context.LostFoundItems.Add(model);

            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Lost item reported successfully!";

            return RedirectToAction(nameof(ReportLost));
        }

        // REPORT FOUND
        [HttpGet]
        public IActionResult ReportFound()
        {
            return View();
        }

        // ITEMS - LOAD DATA FROM DATABASE
        [HttpGet]
        public async Task<IActionResult> Items()
        {
            var items = await _context.LostFoundItems
                .OrderByDescending(item => item.CreatedAt)
                .ToListAsync();

            return View(items);
        }

        // SEARCH
        [HttpGet]
        public IActionResult Search(string? query)
        {
            ViewData["SearchQuery"] = query ?? "";

            return View();
        }

        // OTHER PAGES
        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Categories()
        {
            return View();
        }

        public IActionResult ItemDetails()
        {
            return View();
        }

        // REGISTER - GET
        [HttpGet]
        public IActionResult Register()
        {
            return View(new RegisterViewModel());
        }

        // REGISTER - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var email = model.Email.Trim();

            var user = new ApplicationUser
            {
                FullName = model.FullName.Trim(),
                UserName = email,
                Email = email,
                PhoneNumber = model.PhoneNumber.Trim()
            };

            var result = await _userManager.CreateAsync(user, model.Password);

            if (result.Succeeded)
            {
                await _signInManager.SignInAsync(user, isPersistent: false);

                return RedirectToAction(nameof(Index));
            }

            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }

            return View(model);
        }

        // LOGIN - GET
        [HttpGet]
        public IActionResult Login()
        {
            return View(new LoginViewModel());
        }

        // LOGIN - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await _signInManager.PasswordSignInAsync(
                model.Email.Trim(),
                model.Password,
                model.RememberMe,
                lockoutOnFailure: true
            );

            if (result.Succeeded)
            {
                return RedirectToAction(nameof(Index));
            }

            if (result.IsLockedOut)
            {
                ModelState.AddModelError(
                    "",
                    "Account temporarily locked. Try again later."
                );
            }
            else
            {
                ModelState.AddModelError(
                    "",
                    "Invalid email or password."
                );
            }

            return View(model);
        }

        // LOGOUT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();

            return RedirectToAction(nameof(Index));
        }

        // FORGOT PASSWORD
        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        // ERROR
        [ResponseCache(
            Duration = 0,
            Location = ResponseCacheLocation.None,
            NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}