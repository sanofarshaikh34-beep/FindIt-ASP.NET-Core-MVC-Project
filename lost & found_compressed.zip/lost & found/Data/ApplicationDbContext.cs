using lost___found.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace lost___found.Data
{
public class ApplicationDbContext
: IdentityDbContext<ApplicationUser>
{
public ApplicationDbContext(
DbContextOptions<ApplicationDbContext> options)
: base(options)
{
}


    public DbSet<LostFoundItem> LostFoundItems { get; set; }
}

}
