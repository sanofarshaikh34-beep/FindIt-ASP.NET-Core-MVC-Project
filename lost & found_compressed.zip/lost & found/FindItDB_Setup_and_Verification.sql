/*
    FindIt – Lost and Found Management System
    SQL Server setup and verification script

    IMPORTANT:
    - This script creates the FindItDB database if it does not exist.
    - Run Entity Framework Core migrations from the project folder
      to create/update the Identity and application tables:
          dotnet ef database update
    - Do not manually create tables here if EF Core migrations manage them.
*/

USE master;
GO

IF DB_ID(N'FindItDB') IS NULL
BEGIN
    CREATE DATABASE FindItDB;
    PRINT 'Database FindItDB created.';
END
ELSE
BEGIN
    PRINT 'Database FindItDB already exists.';
END
GO

USE FindItDB;
GO

-- Check whether the expected ASP.NET Core Identity tables exist.
SELECT
    TABLE_SCHEMA,
    TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
  AND TABLE_NAME IN
  (
      'AspNetUsers',
      'AspNetRoles',
      'AspNetUserClaims',
      'AspNetUserLogins',
      'AspNetUserRoles',
      'AspNetUserTokens',
      'AspNetRoleClaims',
      'LostFoundItems'
  )
ORDER BY TABLE_NAME;
GO

-- Check the columns of the LostFoundItems table, if it exists.
IF OBJECT_ID(N'dbo.LostFoundItems', N'U') IS NOT NULL
BEGIN
    PRINT 'LostFoundItems table exists. Column details:';

    SELECT
        COLUMN_NAME,
        DATA_TYPE,
        CHARACTER_MAXIMUM_LENGTH,
        IS_NULLABLE
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'dbo'
      AND TABLE_NAME = 'LostFoundItems'
    ORDER BY ORDINAL_POSITION;

    -- View the most recently created lost-item records.
    SELECT TOP (100) *
    FROM dbo.LostFoundItems
    ORDER BY CreatedAt DESC;
END
ELSE
BEGIN
    PRINT 'LostFoundItems table does not exist yet. Run: dotnet ef database update';
END
GO

-- Count records in the lost-item table, if it exists.
IF OBJECT_ID(N'dbo.LostFoundItems', N'U') IS NOT NULL
BEGIN
    SELECT COUNT(*) AS TotalLostFoundItems
    FROM dbo.LostFoundItems;
END
GO
