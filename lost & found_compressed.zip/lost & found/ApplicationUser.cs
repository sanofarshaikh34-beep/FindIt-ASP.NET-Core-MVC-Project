
using Microsoft.AspNetCore.Identity;

namespace lost___found.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string FullName { get; set; } = string.Empty;
    }
}
